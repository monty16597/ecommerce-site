import json
import boto3
from decimal import Decimal

# Helper class to convert a DynamoDB item to a JSON serializable format
# This is necessary because DynamoDB stores numbers as Decimal, which
# is not directly supported by the standard JSON library.
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return json.JSONEncoder.default(self, obj)

# Initialize the DynamoDB client
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ecommerce-data') # Replace 'Products' with your table name

def lambda_handler(event, context):
    """
    Handles requests to retrieve products from the DynamoDB table.

    The function supports the following queries:
    1. No query parameters: Fetches all products (use with caution for large tables).
    2. 'category' query parameter: Fetches products by category.
    3. 'featured' query parameter: Fetches products where 'featured' is true.
    """
    try:
        # Check for query string parameters to filter results
        query_params = event.get('queryStringParameters', {})
        
        if query_params:
            if 'category' in query_params:
                # Query the GSI to find items by category
                category_name = query_params['category']
                response = table.query(
                    IndexName='CategoryIndex',
                    KeyConditionExpression='category = :cat',
                    ExpressionAttributeValues={':cat': category_name}
                )
                items = response.get('Items', [])
            elif 'featured' in query_params:
                # Scan the table for featured items
                # NOTE: For very large datasets, a GSI would be more efficient.
                # Here, we assume a small number of featured items.
                response = table.scan(
                    FilterExpression='featured = :val',
                    ExpressionAttributeValues={':val': True}
                )
                items = response.get('Items', [])
            else:
                # If no recognized query parameters, return a bad request error
                return {
                    'statusCode': 400,
                    'body': json.dumps({'message': 'Invalid query parameter provided.'})
                }
        else:
            # If no query parameters, scan the entire table
            # WARNING: This is inefficient for large tables and should be avoided in production.
            response = table.scan()
            items = response.get('Items', [])
        
        # Return a successful response with the retrieved items
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*' # Required for CORS
            },
            'body': json.dumps(items, cls=DecimalEncoder)
        }
    except Exception as e:
        # Handle any errors during the process
        print(e)
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Internal Server Error', 'error': str(e)})
        }